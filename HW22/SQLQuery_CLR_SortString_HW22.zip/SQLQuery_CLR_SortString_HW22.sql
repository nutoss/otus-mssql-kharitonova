
-- �������� CLR
EXEC sp_configure 'show advanced options', 1;
GO
RECONFIGURE;
GO

EXEC sp_configure 'clr enabled', 1;
EXEC sp_configure 'clr strict security', 0;
GO


CREATE ASSEMBLY CLRSortString FROM 'C:\Users\annaakh\Documents\SQLServerCLRSortString\SQLServerCLRSortString\bin\Debug\SQLServerCLRSortString.dll'  
GO 

CREATE FUNCTION dbo.SortString(@Name NVARCHAR(MAX))  
RETURNS NVARCHAR(MAX)
AS EXTERNAL NAME [CLRSortString].[SQLServerCLRSortString.CLRFunctions].SortString;

SELECT dbo.SortString('apple,pear,orange,banana,grape,kiwi')